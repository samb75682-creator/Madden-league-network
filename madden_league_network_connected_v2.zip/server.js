const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "madden-data.json");

fs.mkdirSync(DATA_DIR, { recursive: true });

function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { updatedAt:null, leagueId:null, teams:[], standings:[], players:[], weeks:{} }; }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.use(express.text({ type: "*/*", limit: "50mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_,res)=>res.json({ok:true, updatedAt:loadData().updatedAt}));

app.get("/api/data", (_,res)=>res.json(loadData()));

function mergeArray(target, rows, keyFn) {
  const map = new Map((target||[]).map(x=>[keyFn(x),x]));
  for (const row of (rows||[])) map.set(keyFn(row), row);
  return [...map.values()];
}

/*
  These POST routes intentionally mirror the Companion-App exporter pattern.
  The Companion App sends league info, standings, schedules, team stats and
  player stat tables to the export URL.
*/
app.post("/:platform/:leagueId/leagueteams", (req,res)=>{
  const d=loadData(), body=JSON.parse(req.body||"{}");
  d.leagueId=Number(req.params.leagueId);
  d.teams=mergeArray(d.teams, body.leagueTeamInfoList||[], x=>String(x.teamId));
  d.updatedAt=new Date().toISOString(); saveData(d); res.sendStatus(200);
});

app.post("/:platform/:leagueId/standings", (req,res)=>{
  const d=loadData(), body=JSON.parse(req.body||"{}");
  d.leagueId=Number(req.params.leagueId);
  d.standings=mergeArray(d.standings, body.teamStandingInfoList||[],
    x=>[x.teamId,x.calendarYear,x.weekIndex].join("|"));
  d.updatedAt=new Date().toISOString(); saveData(d); res.sendStatus(200);
});

app.post("/:platform/:leagueId/week/:weekType/:weekNumber/:dataType", (req,res)=>{
  const d=loadData(), body=JSON.parse(req.body||"{}");
  const leagueId=Number(req.params.leagueId), weekType=req.params.weekType, weekNumber=Number(req.params.weekNumber), type=req.params.dataType;
  d.leagueId=leagueId;
  const wk=`${weekType}-${weekNumber}`;
  d.weeks[wk] ||= {};
  let listKey = {
    schedules:"gameScheduleInfoList", teamstats:"teamStatInfoList",
    defense:"playerDefensiveStatInfoList", passing:"playerPassingStatInfoList",
    rushing:"playerRushingStatInfoList", receiving:"playerReceivingStatInfoList",
    kicking:"playerKickingStatInfoList", punting:"playerPuntingStatInfoList"
  }[type];
  d.weeks[wk][type]=body[listKey] || [];
  d.updatedAt=new Date().toISOString(); saveData(d); res.sendStatus(200);
});

app.post("/:platform/:leagueId/:teamId/roster", (req,res)=>{
  const d=loadData(), body=JSON.parse(req.body||"{}");
  const rows=body.rosterInfoList||[];
  d.players=mergeArray(d.players, rows, x=>String(x.rosterId||x.playerId||JSON.stringify(x)));
  d.updatedAt=new Date().toISOString(); saveData(d); res.sendStatus(200);
});

app.post("/:platform/:leagueId/freeagents/roster", (req,res)=>{
  const d=loadData(), body=JSON.parse(req.body||"{}");
  const rows=body.rosterInfoList||[];
  d.players=mergeArray(d.players, rows, x=>String(x.rosterId||x.playerId||JSON.stringify(x)));
  d.updatedAt=new Date().toISOString(); saveData(d); res.sendStatus(200);
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`Madden League Network running on ${PORT}`));
